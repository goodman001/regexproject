#!/usr/bin/perl -w

$x = 1;
while ($x <= 10) {
	print "$x\n";
	$x = $x + 1;
}
