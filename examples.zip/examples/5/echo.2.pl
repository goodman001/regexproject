#!/usr/bin/perl -w
# writen by andrewt@cse.unsw.edu.au as a COMP2041 example
# Python implementation of /bin/echo
print join(" ", @ARGV), "\n";
