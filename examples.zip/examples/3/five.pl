#!/usr/bin/perl -w

foreach $i (0..4) {
    print "$i\n"
}
