#!/usr/bin/python3

answer = 6 * 7
print(answer)