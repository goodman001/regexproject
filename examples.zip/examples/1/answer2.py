#!/usr/bin/python3

answer = 1 + 7 * 7 -8
print(answer)